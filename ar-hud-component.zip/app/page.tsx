import SciFiHUD from "@/components/sci-fi-hud"

export default function Page() {
  return <SciFiHUD />
}
