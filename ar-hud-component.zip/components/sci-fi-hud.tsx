"use client"

import { useEffect, useRef, useState, useCallback } from "react"

// ─────────────────────────────────────────────
// Types
// ─────────────────────────────────────────────
export type HudMode = "COLOR" | "IR"
export type TrackingState = "SCANNING" | "ACQUIRING" | "LOCKED" | "LOST"

export interface SciFiHUDProps {
  mode?: HudMode
  trackingState?: TrackingState
  signalStrength?: number // 0–100
  enableMouseParallax?: boolean
  enableGyroParallax?: boolean
  onToggleMode?: () => void
  onOpenGateway?: () => void
}

// ─────────────────────────────────────────────
// Color palette per mode
// ─────────────────────────────────────────────
function useModeColors(mode: HudMode) {
  if (mode === "IR") {
    return {
      primary: "#e63030",
      secondary: "#ff6b6b",
      dim: "rgba(230,48,48,0.5)",
      faint: "rgba(230,48,48,0.2)",
      glow: "rgba(230,48,48,0.15)",
      amber: "#f5a623",
      text: "text-[#e63030]",
      textDim: "text-[#e63030]/60",
      textFaint: "text-[#e63030]/40",
      border: "border-[#e63030]/30",
      borderDim: "border-[#e63030]/15",
      bg: "bg-[#e63030]/10",
      bgFaint: "bg-[#e63030]/5",
      pulse: "bg-[#e63030]",
    }
  }
  return {
    primary: "#00f2ff",
    secondary: "#7ef9ff",
    dim: "rgba(0,242,255,0.5)",
    faint: "rgba(0,242,255,0.2)",
    glow: "rgba(0,242,255,0.12)",
    amber: "#f5a623",
    text: "text-[#00f2ff]",
    textDim: "text-[#00f2ff]/60",
    textFaint: "text-[#00f2ff]/40",
    border: "border-[#00f2ff]/30",
    borderDim: "border-[#00f2ff]/15",
    bg: "bg-[#00f2ff]/10",
    bgFaint: "bg-[#00f2ff]/5",
    pulse: "bg-[#00f2ff]",
  }
}

// ─────────────────────────────────────────────
// Hooks
// ─────────────────────────────────────────────
function useTimecode() {
  const [tc, setTc] = useState("00:00:00:00")
  const startRef = useRef(Date.now())
  useEffect(() => {
    const id = setInterval(() => {
      const elapsed = Date.now() - startRef.current
      const totalFrames = Math.floor(elapsed / (1000 / 25))
      const frames = totalFrames % 25
      const seconds = Math.floor(totalFrames / 25) % 60
      const minutes = Math.floor(totalFrames / (25 * 60)) % 60
      const hours = Math.floor(totalFrames / (25 * 3600)) % 24
      setTc(
        `${String(hours).padStart(2, "0")}:${String(minutes).padStart(2, "0")}:${String(seconds).padStart(2, "0")}:${String(frames).padStart(2, "0")}`
      )
    }, 40)
    return () => clearInterval(id)
  }, [])
  return tc
}

function useUtcTime() {
  const [utc, setUtc] = useState("")
  useEffect(() => {
    const id = setInterval(() => {
      const d = new Date()
      setUtc(
        `${String(d.getUTCHours()).padStart(2, "0")}:${String(d.getUTCMinutes()).padStart(2, "0")}:${String(d.getUTCSeconds()).padStart(2, "0")}`
      )
    }, 1000)
    setUtc(() => {
      const d = new Date()
      return `${String(d.getUTCHours()).padStart(2, "0")}:${String(d.getUTCMinutes()).padStart(2, "0")}:${String(d.getUTCSeconds()).padStart(2, "0")}`
    })
    return () => clearInterval(id)
  }, [])
  return utc
}

// ─────────────────────────────────────────────
// Parallax hook for mouse movement
// ─────────────────────────────────────────────
function useMouseParallax(enabled: boolean) {
  const [offset, setOffset] = useState({ x: 0, y: 0 })

  useEffect(() => {
    if (!enabled) return

    const handleMouseMove = (e: MouseEvent) => {
      const x = (e.clientX / window.innerWidth - 0.5) * 2 // -1 to 1
      const y = (e.clientY / window.innerHeight - 0.5) * 2
      // Subtle parallax — max 4px displacement
      setOffset({
        x: x * 4,
        y: y * 4,
      })
    }

    window.addEventListener("mousemove", handleMouseMove)
    return () => window.removeEventListener("mousemove", handleMouseMove)
  }, [enabled])

  return offset
}

// Parallax hook for device orientation (gyroscope)
function useGyroParallax(enabled: boolean) {
  const [offset, setOffset] = useState({ x: 0, y: 0 })

  useEffect(() => {
    if (!enabled) return

    const handleDeviceOrientation = (e: DeviceOrientationEvent) => {
      if (e.alpha === null || e.beta === null) return
      // Subtle parallax based on device tilt
      // beta: -180 to 180 (left/right), alpha: 0 to 360 (up/down)
      const x = ((e.alpha || 0) / 360 - 0.5) * 2
      const y = ((e.beta || 0) / 180 - 0.5) * 2
      setOffset({
        x: x * 4,
        y: y * 4,
      })
    }

    // Only add listener if supported
    if (typeof window !== "undefined" && "DeviceOrientationEvent" in window) {
      window.addEventListener("deviceorientation", handleDeviceOrientation)
      return () => window.removeEventListener("deviceorientation", handleDeviceOrientation)
    }
  }, [enabled])

  return offset
}

// ─────────────────────────────────────────────
// Glitch text
// ─────────────────────────────────────────────
function GlitchText({ children, className }: { children: string; className?: string }) {
  const [display, setDisplay] = useState(children)
  useEffect(() => {
    const chars = "█▓▒░_"
    let t: ReturnType<typeof setTimeout>
    const tick = () => {
      if (Math.random() > 0.94) {
        const arr = children.split("")
        arr[Math.floor(Math.random() * arr.length)] = chars[Math.floor(Math.random() * chars.length)]
        setDisplay(arr.join(""))
        setTimeout(() => setDisplay(children), 60)
      }
      t = setTimeout(tick, 120 + Math.random() * 180)
    }
    tick()
    return () => clearTimeout(t)
  }, [children])
  return <span className={className}>{display}</span>
}

// ─────────────────────────────────────────────
// Signal bar visualizer
// ─────────────────────────────────────────────
function SignalBars({ strength, color }: { strength: number; color: string }) {
  const bars = 12
  const active = Math.round((strength / 100) * bars)
  return (
    <div className="flex items-end gap-[2px]">
      {Array.from({ length: bars }).map((_, i) => {
        const height = 4 + i * 1.5
        const isActive = i < active
        return (
          <div
            key={i}
            style={{
              width: 3,
              height,
              backgroundColor: isActive ? color : `${color}30`,
            }}
          />
        )
      })}
    </div>
  )
}

// ─────────────────────────────────────────────
// Corner bracket
// ─────────────────────────────────────────────
function CornerBracket({ pos, color, size = 10 }: { pos: "tl" | "tr" | "bl" | "br"; color: string; size?: number }) {
  const d =
    pos === "tl"
      ? `M0 ${size} L0 0 L${size} 0`
      : pos === "tr"
      ? `M0 0 L${size} 0 L${size} ${size}`
      : pos === "bl"
      ? `M0 0 L0 ${size} L${size} ${size}`
      : `M0 ${size} L${size} ${size} L${size} 0`
  const posClass =
    pos === "tl"
      ? "top-0 left-0"
      : pos === "tr"
      ? "top-0 right-0"
      : pos === "bl"
      ? "bottom-0 left-0"
      : "bottom-0 right-0"
  return (
    <svg
      className={`absolute ${posClass}`}
      width={size}
      height={size}
      viewBox={`0 0 ${size} ${size}`}
    >
      <path d={d} fill="none" stroke={color} strokeWidth="1" />
    </svg>
  )
}

function BoxBrackets({ color, children, className }: { color: string; children?: React.ReactNode; className?: string }) {
  return (
    <div className={`relative ${className ?? ""}`}>
      <CornerBracket pos="tl" color={color} />
      <CornerBracket pos="tr" color={color} />
      <CornerBracket pos="bl" color={color} />
      <CornerBracket pos="br" color={color} />
      {children}
    </div>
  )
}

// ─────────────────────────────────────────────
// Reticle / lock ring
// ─────────────────────────────────────────────
function LockReticle({ rotation, color, locked }: { rotation: number; color: string; locked: boolean }) {
  const segments = 24
  const gap = 3
  const r = 120
  const cx = 150
  const cy = 150

  return (
    <svg viewBox="0 0 300 300" className="w-full h-full">
      {/* Outer ring segments */}
      <g transform={`rotate(${rotation} ${cx} ${cy})`}>
        {Array.from({ length: segments }).map((_, i) => {
          const startAngle = (i * 360) / segments
          const endAngle = ((i + 1) * 360) / segments - gap
          const s = ((startAngle - 90) * Math.PI) / 180
          const e = ((endAngle - 90) * Math.PI) / 180
          const x1 = cx + r * Math.cos(s)
          const y1 = cy + r * Math.sin(s)
          const x2 = cx + r * Math.cos(e)
          const y2 = cy + r * Math.sin(e)
          const large = endAngle - startAngle > 180 ? 1 : 0
          return (
            <path
              key={i}
              d={`M ${x1} ${y1} A ${r} ${r} 0 ${large} 1 ${x2} ${y2}`}
              fill="none"
              stroke={color}
              strokeWidth={locked ? "1.5" : "0.8"}
              opacity={locked ? 0.7 : 0.3}
            />
          )
        })}
      </g>

      {/* Middle ring */}
      <circle cx={cx} cy={cy} r="90" fill="none" stroke={color} strokeWidth="0.5" opacity="0.25"
        strokeDasharray="4 8" transform={`rotate(${-rotation * 0.6} ${cx} ${cy})`} />

      {/* Inner ring */}
      <circle cx={cx} cy={cy} r="60" fill="none" stroke={color} strokeWidth="0.5" opacity="0.15" />

      {/* Crosshair lines */}
      <line x1={cx} y1="20" x2={cx} y2="55" stroke={color} strokeWidth="0.7" opacity="0.5" />
      <line x1={cx} y1="245" x2={cx} y2="280" stroke={color} strokeWidth="0.7" opacity="0.5" />
      <line x1="20" y1={cy} x2="55" y2={cy} stroke={color} strokeWidth="0.7" opacity="0.5" />
      <line x1="245" y1={cy} x2="280" y2={cy} stroke={color} strokeWidth="0.7" opacity="0.5" />

      {/* Corner brackets inside ring */}
      <path d={`M${cx - 55} ${cy - 45} L${cx - 55} ${cy - 55} L${cx - 45} ${cy - 55}`}
        fill="none" stroke={color} strokeWidth="1" opacity="0.6" />
      <path d={`M${cx + 45} ${cy - 55} L${cx + 55} ${cy - 55} L${cx + 55} ${cy - 45}`}
        fill="none" stroke={color} strokeWidth="1" opacity="0.6" />
      <path d={`M${cx - 55} ${cy + 45} L${cx - 55} ${cy + 55} L${cx - 45} ${cy + 55}`}
        fill="none" stroke={color} strokeWidth="1" opacity="0.6" />
      <path d={`M${cx + 45} ${cy + 55} L${cx + 55} ${cy + 55} L${cx + 55} ${cy + 45}`}
        fill="none" stroke={color} strokeWidth="1" opacity="0.6" />

      {/* Center dot */}
      <circle cx={cx} cy={cy} r="3" fill={color} opacity={locked ? 0.9 : 0.4} />
      <circle cx={cx} cy={cy} r="6" fill="none" stroke={color} strokeWidth="0.5" opacity="0.5" />
    </svg>
  )
}

// ─────────────────────────────────────────────
// Octagon shape button
// ─────────────────────────────────────────────
function OctagonButton({
  children,
  color,
  active = false,
  size = 56,
}: {
  children: React.ReactNode
  color: string
  active?: boolean
  size?: number
}) {
  const clip = `polygon(25% 0%, 75% 0%, 100% 25%, 100% 75%, 75% 100%, 25% 100%, 0% 75%, 0% 25%)`
  return (
    <div
      className="relative flex items-center justify-center"
      style={{ width: size, height: size }}
    >
      {/* Outer octagon border */}
      <div
        className="absolute inset-0"
        style={{
          clipPath: clip,
          border: `1px solid ${color}`,
          backgroundColor: active ? `${color}20` : "transparent",
        }}
      />
      <span className="relative z-10 font-mono font-bold" style={{ color, fontSize: 14, letterSpacing: "0.1em" }}>
        {children}
      </span>
    </div>
  )
}

// ─────────────────────────────────────────────
// Main HUD frame — outer border with tick marks
// ─────────────────────────────────────────────
function HudFrame({ color }: { color: string }) {
  return (
    <svg className="absolute inset-0 w-full h-full pointer-events-none" preserveAspectRatio="none" viewBox="0 0 390 844">
      {/* Outer border — break at top center and bottom center */}
      <path d="M60 2 L330 2" stroke={color} strokeWidth="0.8" opacity="0.5" />
      <path d="M2 60 L2 784" stroke={color} strokeWidth="0.8" opacity="0.5" />
      <path d="M388 60 L388 784" stroke={color} strokeWidth="0.8" opacity="0.5" />
      <path d="M60 842 L175 842" stroke={color} strokeWidth="0.8" opacity="0.5" />
      <path d="M215 842 L330 842" stroke={color} strokeWidth="0.8" opacity="0.5" />

      {/* Corner connectors */}
      <path d="M2 60 Q2 2 60 2" fill="none" stroke={color} strokeWidth="0.8" opacity="0.5" />
      <path d="M330 2 Q388 2 388 60" fill="none" stroke={color} strokeWidth="0.8" opacity="0.5" />
      <path d="M2 784 Q2 842 60 842" fill="none" stroke={color} strokeWidth="0.8" opacity="0.5" />
      <path d="M330 842 Q388 842 388 784" fill="none" stroke={color} strokeWidth="0.8" opacity="0.5" />

      {/* Left side tick marks */}
      {Array.from({ length: 18 }).map((_, i) => (
        <line
          key={`lt-${i}`}
          x1="2" y1={120 + i * 34} x2={i % 4 === 0 ? 10 : 6} y2={120 + i * 34}
          stroke={color} strokeWidth="0.7" opacity="0.35"
        />
      ))}

      {/* Right side tick marks */}
      {Array.from({ length: 18 }).map((_, i) => (
        <line
          key={`rt-${i}`}
          x1="388" y1={120 + i * 34} x2={i % 4 === 0 ? 380 : 384} y2={120 + i * 34}
          stroke={color} strokeWidth="0.7" opacity="0.35"
        />
      ))}

      {/* Left arrow / chevron at mid */}
      <path d="M6 320 L14 312 L14 328 Z" fill={color} opacity="0.6" />
      {/* Right arrow / chevron at mid */}
      <path d="M384 320 L376 312 L376 328 Z" fill={color} opacity="0.6" />

      {/* Top center tick */}
      <line x1="195" y1="0" x2="195" y2="8" stroke={color} strokeWidth="0.8" opacity="0.4" />
    </svg>
  )
}

// ─────────────────────────────────────────────
// Analysis panel (right side in IR mode)
// ─────────────────────────────────────────────
function AnalysisPanel({ color, amber }: { color: string; amber: string }) {
  const readings = [
    { label: "FREQ", value: "440.12 Hz" },
    { label: "AMP", value: "-12.4 dB" },
    { label: "PHASE", value: "98.1 %" },
    { label: "TEMP", value: "41.2 °C" },
    { label: "EMF", value: "0.0032 μT" },
  ]
  return (
    <div className="space-y-2">
      <div className="font-mono text-[8px] tracking-[0.25em]" style={{ color, opacity: 0.7 }}>
        ANALYSIS
      </div>
      <div
        className="w-full h-px"
        style={{ backgroundColor: color, opacity: 0.3 }}
      />
      <div className="space-y-2 pt-1">
        {readings.map((r) => (
          <div key={r.label} className="space-y-0.5">
            <div className="font-mono text-[8px] tracking-[0.2em]" style={{ color, opacity: 0.5 }}>
              {r.label}
            </div>
            <div className="font-mono text-[9px] tabular-nums" style={{ color: amber, opacity: 0.85 }}>
              {r.value}
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

// ─────────────────────────────────────────────
// Main component
// ─────────────────────────────────────────────
export default function SciFiHUD({
  mode: modeProp = "COLOR",
  trackingState: trackingProp = "LOCKED",
  signalStrength: signalProp = 72,
  enableMouseParallax = false,
  enableGyroParallax = false,
  onToggleMode,
  onOpenGateway,
}: SciFiHUDProps) {
  const [mode, setMode] = useState<HudMode>(modeProp)
  const [trackingState, setTrackingState] = useState<TrackingState>(trackingProp)
  const [signalStrength] = useState(signalProp)
  const [rotation, setRotation] = useState(0)
  const c = useModeColors(mode)
  const tc = useTimecode()
  const utc = useUtcTime()
  const mouseOffset = useMouseParallax(enableMouseParallax)
  const gyroOffset = useGyroParallax(enableGyroParallax)

  // Use whichever parallax is enabled
  const parallaxOffset = enableMouseParallax ? mouseOffset : gyroOffset

  const isIR = mode === "IR"
  const isLocked = trackingState === "LOCKED"

  // Slow ring rotation
  useEffect(() => {
    const id = setInterval(() => setRotation((r) => r + 0.4), 50)
    return () => clearInterval(id)
  }, [])

  const toggleMode = useCallback(() => {
    setMode((m) => (m === "COLOR" ? "IR" : "COLOR"))
    setTrackingState("ACQUIRING")
    setTimeout(() => setTrackingState("LOCKED"), 1800)
    onToggleMode?.()
  }, [onToggleMode])

  const handleOpenGateway = useCallback(() => {
    onOpenGateway?.()
  }, [onOpenGateway])

  return (
    <div
      className="fixed inset-0 flex items-center justify-center bg-black overflow-hidden font-mono select-none"
      style={{ backgroundColor: "#050505" }}
    >
      {/* Scanline overlay (foreground) */}
      <div
        className="absolute inset-0 pointer-events-none z-50"
        style={{
          backgroundImage:
            "repeating-linear-gradient(0deg, transparent, transparent 3px, rgba(0,0,0,0.07) 3px, rgba(0,0,0,0.07) 4px)",
        }}
      />

      {/* HUD phone-sized container */}
      <div
        className="relative w-full max-w-[390px] h-full max-h-[844px] overflow-hidden"
        style={{ backgroundColor: "#050505" }}
      >
        {/* ──────────────────────────────────── */}
        {/* LAYER 1: Background grid / frame */}
        {/* ──────────────────────────────────── */}
        <div
          className="absolute inset-0"
          style={{
            transform: `translate(${parallaxOffset.x * 0.3}px, ${parallaxOffset.y * 0.3}px)`,
            transition: "transform 0.05s ease-out",
          }}
        >
          <HudFrame color={c.primary} />
        </div>

        {/* ──────────────────────────────────── */}
        {/* LAYER 2: Main telemetry & reticle */}
        {/* ──────────────────────────────────── */}
        <div
          className="absolute inset-0"
          style={{
            transform: `translate(${parallaxOffset.x * 0.6}px, ${parallaxOffset.y * 0.6}px)`,
            transition: "transform 0.05s ease-out",
          }}
        >
          {/* TOP BAR */}
          <div className="absolute top-0 left-0 right-0 px-4 pt-3 flex items-start justify-between z-20">
            {/* Left: system status */}
            <div className="space-y-0.5">
              <div
                className="text-[8px] tracking-[0.2em] uppercase"
                style={{ color: c.primary, opacity: 0.7 }}
              >
                SYSTEM_LINK: FOCUS LOCK
              </div>
              <div
                className="text-[8px] tracking-[0.2em] uppercase"
                style={{ color: c.primary, opacity: 0.7 }}
              >
                PROBE_STATE: ACTIVE
              </div>
              <div className="text-[13px] font-bold tracking-[0.25em] text-white uppercase mt-1">
                SECTOR: HERO
              </div>
              <div
                className="text-[10px] tracking-[0.18em] tabular-nums"
                style={{ color: c.primary, opacity: 0.8 }}
              >
                TC&nbsp;&nbsp;{tc}
              </div>
            </div>

            {/* Right: mode button + rotate label */}
            <div className="flex flex-col items-end gap-1">
              <button
                onClick={toggleMode}
                className="relative px-3 py-1.5 text-[9px] tracking-[0.2em] uppercase transition-all pointer-events-auto"
                style={{
                  color: c.primary,
                  border: `1px solid ${c.primary}`,
                  opacity: 0.9,
                }}
              >
                MODE [1]
              </button>
              <button
                onClick={toggleMode}
                className="text-[8px] tracking-[0.15em] uppercase transition-colors pointer-events-auto"
                style={{ color: c.primary, opacity: 0.55 }}
              >
                ROTATE &gt;&gt;
              </button>
            </div>
          </div>

          {/* IR MODE label + down triangle */}
          <div className="absolute top-[88px] left-0 right-0 flex flex-col items-center z-20 pointer-events-none">
            <div
              className="text-[9px] tracking-[0.35em] uppercase"
              style={{ color: c.primary, opacity: 0.75 }}
            >
              {isIR ? "IR MODE" : "IR OFF"}
            </div>
            <svg width="12" height="8" viewBox="0 0 12 8" className="mt-1">
              <path
                d={isIR ? "M6 8 L0 0 L12 0 Z" : "M6 0 L0 8 L12 8 Z"}
                fill={c.primary}
                opacity="0.6"
              />
            </svg>
          </div>

          {/* LEFT PANEL — NODE / UTC / SIGNAL */}
          <div className="absolute left-3 top-[140px] z-20 space-y-3 pointer-events-none">
            <div className="space-y-1.5">
              <div
                className="text-[8px] tracking-[0.2em] uppercase"
                style={{ color: c.amber }}
              >
                MODE-A7
              </div>
              <div
                className="text-[9px] tracking-[0.18em] tabular-nums"
                style={{ color: c.textDim }}
              >
                UTC {utc}
              </div>
            </div>

            <div className="space-y-1">
              <div
                className="text-[8px] tracking-[0.2em] uppercase"
                style={{ color: c.textFaint }}
              >
                SIGNAL
              </div>
              <SignalBars strength={signalStrength} color={c.primary} />
            </div>
          </div>

          {/* RIGHT SIDE: IR button / octagon */}
          <div className="absolute top-[150px] right-4 z-20 pointer-events-auto">
            <button
              onClick={toggleMode}
              className="transition-all"
              style={{ pointerEvents: "auto" }}
            >
              <OctagonButton color={c.primary} active={isIR}>
                {isIR ? "IR" : "◆"}
              </OctagonButton>
            </button>
          </div>

          {/* CENTER RETICLE — the focal point over empty AR canvas */}
          <div className="absolute inset-0 flex items-center justify-center z-10 pointer-events-none">
            <div className="relative w-[240px] h-[240px]">
              <LockReticle rotation={rotation} color={c.primary} locked={isLocked} />
            </div>
          </div>

          {/* RIGHT SIDE ANALYSIS PANEL (IR only) */}
          {isIR && (
            <div className="absolute right-4 top-[260px] z-20 max-w-[90px] pointer-events-none">
              <AnalysisPanel color={c.primary} amber={c.amber} />
            </div>
          )}
        </div>

        {/* ──────────────────────────────────── */}
        {/* LAYER 3: Foreground controls & status */}
        {/* ──────────────────────────────────── */}
        <div
          className="absolute inset-0 flex flex-col justify-end z-30 pointer-events-none"
          style={{
            transform: `translate(${parallaxOffset.x * 0.9}px, ${parallaxOffset.y * 0.9}px)`,
            transition: "transform 0.05s ease-out",
          }}
        >
          {/* DEMO badge — IR only */}
          {isIR && (
            <BoxBrackets
              color={c.primary}
              className="absolute bottom-[280px] left-4 p-3 max-w-[90px]"
            >
              <div className="space-y-1">
                <div
                  className="text-[10px] tracking-[0.2em] font-bold uppercase"
                  style={{ color: c.primary }}
                >
                  FIELD DEMO
                </div>
                <div
                  className="text-[8px] tracking-[0.1em] uppercase"
                  style={{ color: c.textDim }}
                >
                  VERSION 0.1
                </div>
              </div>
            </BoxBrackets>
          )}

          {/* HOLD STEADY status bar */}
          <div className="px-4 pb-32 space-y-2 pointer-events-none">
            <div
              className="text-center text-[9px] tracking-[0.25em] uppercase"
              style={{ color: c.primary, opacity: 0.65 }}
            >
              [ HOLD STEADY ]
            </div>

            {/* OPEN WEB GATEWAY button — appears only when locked */}
            {isLocked && (
              <button
                onClick={handleOpenGateway}
                className="w-full py-2 text-[9px] tracking-[0.2em] uppercase transition-all pointer-events-auto"
                style={{
                  color: c.primary,
                  border: `1px solid ${c.primary}`,
                  backgroundColor: `${c.primary}08`,
                  opacity: 0.85,
                }}
              >
                [ OPEN WEB GATEWAY ]
              </button>
            )}
          </div>

          {/* BOTTOM SPECTRUM / CONTROLS */}
          <div className="absolute bottom-0 left-0 right-0 px-4 pb-4 space-y-3 pointer-events-none">
            {/* Spectrum bar */}
            <div className="flex items-end gap-0.5">
              {Array.from({ length: 24 }).map((_, i) => {
                const height = 4 + Math.sin(i * 0.3 + Date.now() / 200) * 3
                return (
                  <div
                    key={i}
                    style={{
                      width: "100%",
                      maxWidth: 6,
                      height: Math.max(4, height),
                      backgroundColor: c.primary,
                      opacity: 0.3 + Math.sin(i * 0.5) * 0.3,
                    }}
                  />
                )
              })}
            </div>

            {/* Control buttons row */}
            <div className="flex items-center justify-between">
              {/* LEFT: Triangle */}
              <div className="pointer-events-auto">
                <svg width="12" height="12" viewBox="0 0 12 12">
                  <path
                    d="M6 0 L12 12 L0 12 Z"
                    fill={c.primary}
                    opacity="0.6"
                  />
                </svg>
              </div>

              {/* CENTER: SPECTRUM COLOR | IR */}
              <div className="flex items-center gap-2 text-[8px] tracking-[0.15em] pointer-events-auto">
                <span style={{ color: c.primary, opacity: 0.5 }}>SPECTRUM</span>
                <span style={{ color: c.primary, opacity: 0.7 }}>COLOR | IR</span>
              </div>

              {/* CENTER INDICATOR: LOCKED */}
              <button
                onClick={() => setTrackingState(isLocked ? "LOST" : "LOCKED")}
                className="w-2.5 h-2.5 rounded-full transition-all pointer-events-auto"
                style={{
                  backgroundColor: isLocked ? c.primary : "rgba(100,100,100,0.5)",
                  boxShadow: isLocked ? `0 0 8px ${c.primary}` : "none",
                }}
              />

              {/* RIGHT: SYSTEM NOMINAL */}
              <div className="flex items-center gap-1 text-[8px] tracking-[0.15em] pointer-events-auto">
                <span style={{ color: c.textDim }}>SYSTEM</span>
                <span style={{ color: c.primary, opacity: 0.7 }}>NOMINAL</span>
                <div
                  className="w-1.5 h-1.5 rounded-full"
                  style={{ backgroundColor: c.primary, opacity: 0.8 }}
                />
              </div>
            </div>

            {/* Bottom toolbar */}
            <div className="flex items-center justify-between">
              {/* LEFT: Triangle icon */}
              <button
                className="pointer-events-auto"
                onClick={() => console.log("Toolbar left action")}
              >
                <svg width="14" height="14" viewBox="0 0 14 14">
                  <path
                    d="M7 0 L14 14 L0 14 Z"
                    fill={c.primary}
                    opacity="0.5"
                  />
                </svg>
              </button>

              {/* CENTER: Mode label button */}
              <button
                onClick={toggleMode}
                className="text-[8px] tracking-[0.2em] uppercase transition-colors pointer-events-auto"
                style={{ color: c.primary, opacity: 0.7 }}
              >
                [ {mode} MODE ]
              </button>

              {/* RIGHT: three dots menu */}
              <button
                className="text-[10px] pointer-events-auto"
                style={{ color: c.primary, opacity: 0.55, letterSpacing: "0.2em" }}
              >
                ...
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
